CREATE TABLE "table" (
	"column9" CHARACTER VARYING(10) DEFAULT 'column9',
	"column10" INT DEFAULT 10
);
