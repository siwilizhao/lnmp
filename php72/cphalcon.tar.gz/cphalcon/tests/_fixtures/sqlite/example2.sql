CREATE TABLE "table" (
	`column2` INTEGER,
	`column3` NUMERIC(10,2) NOT NULL,
	`column1` VARCHAR(10),
	PRIMARY KEY ("column3")
)
