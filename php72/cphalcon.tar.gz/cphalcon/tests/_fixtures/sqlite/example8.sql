CREATE TABLE "table" (
	`column19` DOUBLE,
	`column20` DOUBLE UNSIGNED
)
