<?php

namespace Helper;

/**
 * Unit5x Helper
 *
 * Here you can define custom actions
 * all public methods declared in helper class will be available in $I
 *
 * @package Helper
 */
class Unit5x extends Unit
{

}
