<?php

namespace Helper;

use Codeception\Module;

/**
 * Integration Helper
 *
 * Here you can define custom actions
 * all public methods declared in helper class will be available in $I
 *
 * @package Helper
 */
class Integration extends Module
{
}
