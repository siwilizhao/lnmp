<?php

class Childs extends \Phalcon\Mvc\Model
{
	public $id;

	public $parent;

	public $source;

	public $transaction;

	public $for;

	public $group;
}
