<?php

/**
 * Personnes
 *
 * Personnes is people in french
 */
class Personnes extends Phalcon\Mvc\Model
{

}
