<?php

class Test7Controller extends ControllerBase
{

}
