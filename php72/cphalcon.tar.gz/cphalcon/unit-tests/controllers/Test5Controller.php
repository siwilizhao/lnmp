<?php

class Test5Controller extends Phalcon\Mvc\Controller
{

	public function notFoundAction()
	{
		return 'not-found';
	}

}
